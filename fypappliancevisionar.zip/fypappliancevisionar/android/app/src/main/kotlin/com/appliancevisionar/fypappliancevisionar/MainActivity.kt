package com.appliancevisionar.fypappliancevisionar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
